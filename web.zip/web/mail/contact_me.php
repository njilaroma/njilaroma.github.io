<?php
require('../../vendor/autoload.php');
$sendgrid = new SendGrid('njilaroma', 'njila_roma_06_2016');

header("Access-Control-Allow-Origin: *");

// Check for empty fields
if(empty($_POST['name'])      ||
   empty($_POST['email'])     ||
   empty($_POST['phone'])     ||
   empty($_POST['message'])   ||
   !filter_var($_POST['email'], FILTER_VALIDATE_EMAIL))
   {
   echo "No arguments Provided!";
   return false;
   }

$name = strip_tags(htmlspecialchars($_POST['name']));
$email_address = strip_tags(htmlspecialchars($_POST['email']));
$phone = strip_tags(htmlspecialchars($_POST['phone']));
$message = strip_tags(htmlspecialchars($_POST['message']));


// Create the email and send the message
$to = 'njila.roma@gmail.com'; // Add your email address inbetween the '' replacing yourname@yourdomain.com - This is where the form will send a message to.
$email_subject = "Website Contact Form:  $name";
$email_body = "You have received a new message from your website contact form.\n\n"."Here are the details:\n\nName: $name\n\nEmail: $email_address\n\nPhone: $phone\n\nMessage:\n$message";
$headers = "From: noreply@yourdomain.com\n"; // This is the email address the generated message will be from. We recommend using something like noreply@yourdomain.com.
$headers .= "Reply-To: $email_address";
//mail($to,$email_subject,$email_body,$headers);
//return true;*/


$email = new SendGrid\Email();
$email->addTo($to)
    ->setFrom($email_address)
    ->setSubject($email_subject)
    ->setText($email_body)
    ->setHtml($email_body);

$sendgrid->send($email);

/**
*Email for sender
*/

$email_subject_copy = 'Copy of your message';

$emailForSender = new SendGrid\Email();
$emailForSender->addTo($email_address)
    ->setFrom('noreply@njilaroma.com')
    ->setSubject($email_subject_copy)
    ->setText($message)
    ->setHtml($message);
$sendgrid->send($emailForSender);

return true;

?>
